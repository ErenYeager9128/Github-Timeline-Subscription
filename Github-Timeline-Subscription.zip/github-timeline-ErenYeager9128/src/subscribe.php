<?php
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $otp = generateVerificationCode();
        if (sendVerificationEmail($email, $otp)) {
            echo "OTP sent to $email successfully!";
        } else {
            echo "Failed to send OTP.";
        }
    } else {
        echo "Invalid email address.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Email OTP Verification</title>
</head>
<body>
    <form method="post">
        <input type="email" name="email" required placeholder="Enter your email">
        <button type="submit">Send OTP</button>
    </form>
</body>
</html>
