<?php
echo "<h2>This email is already subscribed.</h2>";
?>
