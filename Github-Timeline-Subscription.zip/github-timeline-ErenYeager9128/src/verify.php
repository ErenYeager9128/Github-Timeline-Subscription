<?php
// Simulate verification check without DB

if (!isset($_GET['email']) || !isset($_GET['code'])) {
    echo "❌ Invalid verification link. Missing parameters.";
    exit;
}

$email = $_GET['email'];
$code = $_GET['code'];

// Simulate verification code (in real case, it'd come from session or a file maybe)
$expectedCode = "123456"; // Replace with a value you're sending in the email

if ($code === $expectedCode) {
    echo "✅ Verification successful for $email!";
} else {
    echo "❌ Invalid or expired verification code.";
}
?>
