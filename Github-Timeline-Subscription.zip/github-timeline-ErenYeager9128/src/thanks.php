<?php
echo "<h2>Thank you for subscribing!</h2>";
?>
