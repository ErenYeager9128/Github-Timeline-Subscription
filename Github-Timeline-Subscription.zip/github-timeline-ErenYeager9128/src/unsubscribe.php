<?php
// src/unsubscribe.php
session_start();

require_once 'functions.php'; // Keep this if you still want to use generateVerificationCode()

$message = '';

function sendUnsubscribeEmail($email, $otp) {
    require '../PHPMailer/src/PHPMailer.php';
    require '../PHPMailer/src/SMTP.php';
    require '../PHPMailer/src/Exception.php';

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'harshamaram69@gmail.com';
        $mail->Password = 'aemrmwqqogkbqwus'; // Use App Password
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('harshamaram69@gmail.com', 'GitHub Timeline');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Unsubscribe OTP';
        $mail->Body = "Your unsubscription verification code is: <b>$otp</b>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Unsubscribe Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}

function unsubscribeEmail($email) {
    // Since no DB, just simulate success
    return true;
}

// Handle unsubscribe email submission
if ($_POST['unsubscribe_email'] ?? false) {
    $email = filter_var($_POST['unsubscribe_email'], FILTER_VALIDATE_EMAIL);
    if ($email) {
        $code = generateVerificationCode(); // Assume this exists in functions.php
        $_SESSION['unsubscribe_code'] = $code;
        $_SESSION['unsubscribe_email'] = $email;

        if (sendUnsubscribeEmail($email, $code)) {
            $message = 'Unsubscribe confirmation code sent to your email!';
        } else {
            $message = 'Failed to send email. Please try again.';
        }
    } else {
        $message = 'Please enter a valid email address.';
    }
}

// Handle verification code
if ($_POST['unsubscribe_verification_code'] ?? false) {
    $code = $_POST['unsubscribe_verification_code'];
    $sessionCode = $_SESSION['unsubscribe_code'] ?? '';
    $email = $_SESSION['unsubscribe_email'] ?? '';

    if ($code === $sessionCode && $email) {
        if (unsubscribeEmail($email)) {
            $message = 'Successfully unsubscribed from GitHub timeline updates!';
            unset($_SESSION['unsubscribe_code'], $_SESSION['unsubscribe_email']);
        } else {
            $message = 'Error processing unsubscription.';
        }
    } else {
        $message = 'Invalid verification code. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Unsubscribe - GitHub Timeline</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .form-group { margin: 20px 0; }
        input[type="email"], input[type="text"] { padding: 10px; width: 300px; border: 1px solid #ccc; }
        button { padding: 10px 20px; background: #dc3545; color: white; border: none; cursor: pointer; }
        button:hover { background: #c82333; }
        .message { padding: 10px; margin: 10px 0; background: #f8f9fa; border: 1px solid #dc3545; }
    </style>
</head>
<body>
    <h1>Unsubscribe from GitHub Timeline Updates</h1>
    
    <?php if ($message): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <h2>Enter Your Email</h2>
    <form method="POST">
        <div class="form-group">
            <label>Email Address:</label><br>
            <input type="email" name="unsubscribe_email" required>
            <button type="submit" id="submit-unsubscribe">Unsubscribe</button>
        </div>
    </form>
    
    <h2>Confirm Unsubscription</h2>
    <form method="POST">
        <div class="form-group">
            <label>Verification Code:</label><br>
            <input type="text" name="unsubscribe_verification_code">
            <button type="submit" id="verify-unsubscribe">Verify</button>
        </div>
    </form>
</body>
</html>
