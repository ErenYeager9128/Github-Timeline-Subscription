#!/bin/bash
# src/setup_cron.sh

# Get the absolute path to the current directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRON_SCRIPT="$SCRIPT_DIR/cron.php"

# Check if PHP is available
if ! command -v php &> /dev/null; then
    echo "Error: PHP is not installed or not in PATH"
    exit 1
fi

# Check if cron.php exists
if [ ! -f "$CRON_SCRIPT" ]; then
    echo "Error: cron.php not found at $CRON_SCRIPT"
    exit 1
fi

# Add the CRON job (every 5 minutes)
CRON_JOB="*/5 * * * * /usr/bin/php $CRON_SCRIPT"

# Check if the job already exists
if crontab -l 2>/dev/null | grep -F "$CRON_SCRIPT" > /dev/null; then
    echo "CRON job already exists for $CRON_SCRIPT"
else
    # Add the new CRON job
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    echo "CRON job added successfully!"
    echo "Job: $CRON_JOB"
fi

# Display current CRON jobs
echo "Current CRON jobs:"
crontab -l
