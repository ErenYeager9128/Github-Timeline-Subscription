<?php
// Email credentials
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_USERNAME', 'harshamaram69@gmail.com');
define('MAIL_PASSWORD', 'aemrmwqqogkbqwus'); // Use App Password
define('MAIL_PORT', 587);
define('MAIL_FROM', 'harshamaram69@gmail.com');
define('MAIL_FROM_NAME', 'GitHub Timeline Subscriptions');
?>
