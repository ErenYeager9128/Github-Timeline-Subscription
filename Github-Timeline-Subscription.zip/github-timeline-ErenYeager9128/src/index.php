<!DOCTYPE html>
<html>
<head>
    <title>GitHub Email Subscription</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 100px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0px 0px 20px rgba(0,0,0,0.1);
            width: 400px;
            text-align: center;
        }
        input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            background: #0066ff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        a {
            text-decoration: none;
            color: #0066ff;
            margin: 10px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>📩 GitHub Email Subscription</h2>

        <form action="subscribe.php" method="POST">
            <input type="email" name="email" placeholder="Enter your email to subscribe" required />
            <button type="submit">Subscribe</button>
        </form>

        <br><a href="unsubscribe.php">🚫 Unsubscribe</a>
    </div>

</body>
</html>
