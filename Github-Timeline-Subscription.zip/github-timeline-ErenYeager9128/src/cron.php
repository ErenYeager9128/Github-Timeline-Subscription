<?php
// src/cron.php
require_once __DIR__ . '/functions.php';

// Log the execution
$logFile = __DIR__ . '/cron.log';
$timestamp = date('Y-m-d H:i:s');

try {
    sendGitHubUpdatesToSubscribers();
    file_put_contents($logFile, "[$timestamp] GitHub updates sent successfully\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents($logFile, "[$timestamp] Error: " . $e->getMessage() . "\n", FILE_APPEND);
}
?>
